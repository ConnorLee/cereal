#!/bin/sh
# Cereal — a local-first workspace for juggling projects.
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "Cereal needs Node.js 22 or newer."
  echo "Install it from https://nodejs.org (the LTS installer), then open this file again."
  echo ""
  printf "Press return to close."; read -r _
  exit 1
fi
if ! node -e 'process.exit(+process.versions.node.split(".")[0] >= 22 ? 0 : 1)'; then
  echo "Cereal needs Node.js 22 or newer. You have $(node -v). Update from https://nodejs.org."
  printf "Press return to close."; read -r _
  exit 1
fi
echo "Starting Cereal at http://127.0.0.1:4317 — close this window to stop it."
( sleep 1; open http://127.0.0.1:4317 ) >/dev/null 2>&1 &
exec node server.mjs
